package com.shiraschool.pranayama

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class PracticeService : Service(), TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var running = false
    private var paused = false
    private var soundOn = true
    private var voiceName: String? = null
    private var phaseIndex = 0
    private var cyclesDone = 0
    private var targetCycles = 0
    private var phaseSeconds = intArrayOf(6, 1, 6, 1)
    private var phaseStarted = 0L
    private var elapsedBeforePause = 0L
    private var sessionStarted = 0L
    private var technique = "Ujjayi"
    private var cycleDuration = 14
    private var tone: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 65)
        createChannel()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("en", "IN")
            voiceName?.let { name -> tts?.voices?.firstOrNull { it.name == name }?.let { tts?.voice = it } }
            if (running && !paused) speakCurrentPhase()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startPractice(intent)
            ACTION_PAUSE -> pausePractice()
            ACTION_RESUME -> resumePractice()
            ACTION_STOP -> stopPractice(true)
            ACTION_SOUND -> { soundOn = intent.getBooleanExtra("sound", true) }
        }
        return START_NOT_STICKY
    }

    private fun startPractice(i: Intent) {
        phaseSeconds = intArrayOf(i.getIntExtra("inhale", 6), i.getIntExtra("inhaleHold", 1), i.getIntExtra("exhale", 6), i.getIntExtra("exhaleHold", 1))
        cycleDuration = phaseSeconds.sum().coerceAtLeast(1)
        targetCycles = (i.getIntExtra("duration", 300) / cycleDuration).coerceAtLeast(1)
        technique = i.getStringExtra("technique") ?: "Ujjayi"
        soundOn = i.getBooleanExtra("sound", true)
        voiceName = i.getStringExtra("voice")
        phaseIndex = 0; cyclesDone = 0; elapsedBeforePause = 0L
        running = true; paused = false; sessionStarted = SystemClock.elapsedRealtime()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Pranayama:PracticeAudio").apply { setReferenceCounted(false); acquire() }
        startForeground(NOTIFICATION_ID, notification("Practice in progress · $technique"))
        broadcast(ACTION_UPDATE, "Preparing", 0, 0)
        if (ttsReady) speakCurrentPhase()
    }

    private fun speakCurrentPhase() {
        if (!running || paused || !ttsReady) return
        if (phaseIndex >= 4) { phaseIndex = 0; cyclesDone++ }
        if (cyclesDone >= targetCycles) { completePractice(); return }
        val labels = arrayOf("Inhale", "Inhale hold", "Exhale", "Exhale hold")
        val index = phaseIndex
        val seconds = phaseSeconds[index]
        if (seconds <= 0) { phaseIndex++; speakCurrentPhase(); return }
        phaseStarted = SystemClock.elapsedRealtime()
        if (soundOn) tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130)
        broadcast(ACTION_UPDATE, labels[index], seconds, elapsedSeconds())
        speak(labels[index]) {
            countSecond(1, seconds, index, SystemClock.elapsedRealtime())
        }
    }

    private fun countSecond(n: Int, total: Int, index: Int, countStartedAt: Long) {
        if (!running || paused || index != phaseIndex) return
        if (n > total) {
            phaseIndex++
            if (phaseIndex >= 4) { phaseIndex = 0; cyclesDone++ }
            broadcast(ACTION_UPDATE, "", 0, elapsedSeconds())
            if (cyclesDone >= targetCycles) completePractice() else speakCurrentPhase()
            return
        }
        broadcast(ACTION_UPDATE, "Second $n", total, elapsedSeconds())
        speak(n.toString()) {
            val wait = (countStartedAt + n * 1000L - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            handler.postDelayed({ countSecond(n + 1, total, index, countStartedAt) }, wait)
        }
    }

    private fun speak(text: String, done: () -> Unit) {
        if (!ttsReady) { handler.postDelayed(done, 1000L); return }
        val utteranceId = "p_${SystemClock.elapsedRealtime()}_${text.hashCode()}"
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { if (id == utteranceId) handler.post(done) }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { if (id == utteranceId) handler.post(done) }
            override fun onError(id: String?, errorCode: Int) { if (id == utteranceId) handler.post(done) }
        })
        val params = android.os.Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f) }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    private fun pausePractice() {
        if (!running || paused) return
        paused = true
        elapsedBeforePause = elapsedSeconds()
        handler.removeCallbacksAndMessages(null)
        tts?.stop()
        broadcast(ACTION_UPDATE, "Paused", 0, elapsedBeforePause.toInt())
        updateNotification("Practice paused")
    }

    private fun resumePractice() {
        if (!running || !paused) return
        paused = false
        sessionStarted = SystemClock.elapsedRealtime()
        updateNotification("Practice in progress · $technique")
        speakCurrentPhase()
    }

    private fun completePractice() {
        val elapsed = elapsedSeconds().toInt()
        running = false; paused = false
        tts?.stop(); handler.removeCallbacksAndMessages(null)
        broadcast(ACTION_COMPLETE, "Complete", targetCycles, elapsed)
        releaseResources()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopPractice(notify: Boolean) {
        running = false; paused = false
        tts?.stop(); handler.removeCallbacksAndMessages(null)
        if (notify) broadcast(ACTION_STOPPED, "Stopped", cyclesDone, elapsedSeconds().toInt())
        releaseResources()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseResources() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    private fun elapsedSeconds(): Long = elapsedBeforePause + if (running && !paused) (SystemClock.elapsedRealtime() - sessionStarted) / 1000L else 0L

    private fun broadcast(action: String, phase: String, count: Int, elapsed: Int) {
        sendBroadcast(Intent(action).setPackage(packageName).putExtra("phase", phase).putExtra("count", count).putExtra("elapsed", elapsed).putExtra("cycles", cyclesDone).putExtra("target", targetCycles).putExtra("technique", technique).putExtra("cycleDuration", cycleDuration))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Pranayama practice", NotificationManager.IMPORTANCE_LOW).apply { description = "Keeps your guided breathing session running while the screen is off" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, PracticeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Pranayama").setContentText(text).setContentIntent(open).setOngoing(true).addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
    }

    private fun updateNotification(text: String) { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text)) }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { releaseResources(); tts?.stop(); tts?.shutdown(); tone?.release(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.shiraschool.pranayama.START"
        const val ACTION_PAUSE = "com.shiraschool.pranayama.PAUSE"
        const val ACTION_RESUME = "com.shiraschool.pranayama.RESUME"
        const val ACTION_STOP = "com.shiraschool.pranayama.STOP"
        const val ACTION_SOUND = "com.shiraschool.pranayama.SOUND"
        const val ACTION_UPDATE = "com.shiraschool.pranayama.UPDATE"
        const val ACTION_COMPLETE = "com.shiraschool.pranayama.COMPLETE"
        const val ACTION_STOPPED = "com.shiraschool.pranayama.STOPPED"
        private const val CHANNEL_ID = "pranayama_practice"
        private const val NOTIFICATION_ID = 41
    }
}
