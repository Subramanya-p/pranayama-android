package com.shiraschool.pranayama

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val paper = 0xFFF5F1E9.toInt(); private val card = 0xFFFFFDF8.toInt(); private val ink = 0xFF273B32.toInt(); private val green = 0xFF3E6654.toInt(); private val muted = 0xFF7D857B.toInt(); private val line = 0xFFD9DED3.toInt()
    private val prefs by lazy { getSharedPreferences("pranayama", MODE_PRIVATE) }
    private var inhale = 6; private var inhaleHold = 1; private var exhale = 6; private var exhaleHold = 1; private var duration = 300
    private var soundOn = true; private var selectedTechnique = 0; private var selectedVoice: String? = null
    private var tts: TextToSpeech? = null; private var voices: List<android.speech.tts.Voice> = emptyList()
    private lateinit var root: LinearLayout; private lateinit var phaseText: TextView; private lateinit var countText: TextView; private lateinit var elapsedText: TextView; private lateinit var cyclesText: TextView; private lateinit var remainingText: TextView; private lateinit var pauseButton: Button; private lateinit var voiceSpinner: Spinner
    private var active = false; private var paused = false; private var lastPhase = "Ready"; private var lastCount = 0; private var lastElapsed = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            lastPhase = intent.getStringExtra("phase") ?: lastPhase; lastCount = intent.getIntExtra("count", lastCount); lastElapsed = intent.getIntExtra("elapsed", lastElapsed)
            val cycles = intent.getIntExtra("cycles", 0); val target = intent.getIntExtra("target", 0); val cycle = intent.getIntExtra("cycleDuration", 14)
            when (intent.action) {
                PracticeService.ACTION_UPDATE -> { active = true; paused = lastPhase == "Paused"; if (::phaseText.isInitialized) renderLive(lastPhase, lastCount, lastElapsed, cycles, target, cycle) }
                PracticeService.ACTION_COMPLETE -> { active = false; paused = false; saveCompletedSession(cycles, lastElapsed, cycle); showCompletion(cycles, lastElapsed, cycle) }
                PracticeService.ACTION_STOPPED -> { active = false; paused = false; showSetup() }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = paper; window.navigationBarColor = paper
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 90)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) { tts?.language = Locale("en", "IN"); voices = tts?.voices?.filter { it.locale.language == "en" } ?: emptyList(); runOnUiThread { if (::voiceSpinner.isInitialized) { val items = listOf("Automatic — prefer Indian English") + voices.map { "${it.name} (${it.locale.displayName})" }; voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items) } } } }
        val filter = IntentFilter().apply { addAction(PracticeService.ACTION_UPDATE); addAction(PracticeService.ACTION_COMPLETE); addAction(PracticeService.ACTION_STOPPED) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        showSetup()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 15f, color: Int = ink, bold: Boolean = false): TextView = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(dp(2), dp(5), dp(2), dp(5)) }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply { text = label; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(green); setOnClickListener { action() } }
    private fun secondary(label: String, action: () -> Unit): Button = Button(this).apply { text = label; setTextColor(green); setBackgroundColor(0xFFE6EADF.toInt()); setOnClickListener { action() } }
    private fun panel(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16)); setBackgroundColor(card) }
    private fun addPanel(parent: LinearLayout, p: LinearLayout) { val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(14)); parent.addView(p, lp) }
    private fun heading(title: String, parent: LinearLayout) { parent.addView(text(title.uppercase(Locale.getDefault()), 11f, muted, true)) }

    private fun base(title: String): LinearLayout {
        val scroll = ScrollView(this).apply { setBackgroundColor(paper); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(22), dp(18), dp(28)) }
        scroll.addView(root); setContentView(scroll)
        root.addView(text("ॐ   PRANAYAMA", 13f, green, true)); root.addView(text(title, 30f, ink)); root.addView(text("Guided breathing · Body, breath and mind", 13f, muted))
        return root
    }

    private fun showSetup() {
        base("Set your breath.\nSet your time.")
        val p = panel(); heading("Choose a pranayama technique", p)
        val names = PracticeData.techniques.map { it.name }
        val techniqueSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names); setSelection(selectedTechnique) }
        p.addView(techniqueSpinner)
        val instruction = text("", 13f, muted); p.addView(instruction)
        val caution = text("", 12f, 0xFF775B34.toInt()); p.addView(caution)
        fun updateTechnique() { val t = PracticeData.techniques[selectedTechnique]; instruction.text = t.steps; caution.text = "Note: ${t.caution}" }
        techniqueSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedTechnique = position; updateTechnique() } }
        updateTechnique(); addPanel(root, p)

        val rhythm = panel(); heading("Breathing rhythm", rhythm)
        val valueViews = mutableMapOf<String, TextView>()
        val time = text("", 22f, green, true)
        val stats = text("", 13f, muted)
        fun refreshStats() {
            val c = (inhale + inhaleHold + exhale + exhaleHold).coerceAtLeast(1)
            val cycles = duration / c
            time.text = String.format(Locale.getDefault(), "%02d:%02d", duration / 60, duration % 60)
            stats.text = "One cycle: $c sec    ·    Full cycles: $cycles    ·    Actual time: ${cycles * c} sec"
        }
        fun phaseRow(label: String, key: String, get: () -> Int, set: (Int) -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(text(label, 14f), LinearLayout.LayoutParams(0, -2, 1f))
            val minus = secondary("−") { set((get() - 1).coerceAtLeast(0)); valueViews[key]?.text = get().toString(); refreshStats() }
            val value = text(get().toString(), 19f, ink, true).apply { gravity = Gravity.CENTER }; valueViews[key] = value
            val plus = secondary("+") { set((get() + 1).coerceAtMost(60)); value.text = get().toString(); refreshStats() }
            row.addView(minus); row.addView(value, LinearLayout.LayoutParams(dp(42), -2)); row.addView(plus); rhythm.addView(row)
        }
        phaseRow("Inhale", "in", { inhale }, { inhale = it }); phaseRow("Inhale hold", "ih", { inhaleHold }, { inhaleHold = it }); phaseRow("Exhale", "ex", { exhale }, { exhale = it }); phaseRow("Exhale hold", "eh", { exhaleHold }, { exhaleHold = it })
        heading("Total practice time", rhythm)
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timeRow.addView(secondary("− 30 sec") { duration = (duration - 30).coerceAtLeast(30); refreshStats() }, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(secondary("+ 30 sec") { duration = (duration + 30).coerceAtMost(3600); refreshStats() }, LinearLayout.LayoutParams(0, -2, 1f)); rhythm.addView(timeRow)
        rhythm.addView(time)
        rhythm.addView(stats)
        refreshStats(); addPanel(root, rhythm)

        val settings = panel(); heading("Voice and sound", settings)
        settings.addView(text("Voice selection (English voices installed on your phone)", 13f, muted))
        val voiceNames = listOf("Automatic — prefer Indian English") + voices.map { "${it.name} (${it.locale.displayName})" }
        voiceSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voiceNames) }
        settings.addView(voiceSpinner)
        voiceSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedVoice = if (position == 0) null else voices.getOrNull(position - 1)?.name } }
        val sound = CheckBox(this).apply { text = "Phase-change bell enabled"; isChecked = soundOn; setTextColor(ink); setOnCheckedChangeListener { _, checked -> soundOn = checked } }; settings.addView(sound)
        val intro = CheckBox(this).apply { text = "Hear technique introduction before starting"; isChecked = true; setTextColor(ink) }; settings.addView(intro)
        addPanel(root, settings)

        val note = panel(); note.addView(text("Practise within your comfortable capacity. Do not force the breath or push through discomfort. If you feel dizzy or unwell, stop and breathe normally.", 13f, 0xFF775B34.toInt())); addPanel(root, note)
        root.addView(button("BEGIN PRACTICE") {
            val t = PracticeData.techniques[selectedTechnique]
            if (intro.isChecked) uSpeak("Today we will practise ${t.name}. ${t.steps} Keep the breath comfortable. If you feel dizzy or uncomfortable, stop and breathe normally.") { launchPractice(t.name) }
            else launchPractice(t.name)
        })
        val progress = panel(); heading("Your journey · Progress and breath capacity", progress); populateProgress(progress); addPanel(root, progress)
    }

    private fun uSpeak(message: String, done: () -> Unit) {
        val introTts = tts
        if (introTts == null) { done(); return }
        introTts.setSpeechRate(0.78f)
        val id = "intro_${System.currentTimeMillis()}"
        introTts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() { override fun onStart(utteranceId: String?) {}; override fun onDone(utteranceId: String?) { if (utteranceId == id) runOnUiThread(done) }; override fun onError(utteranceId: String?) { if (utteranceId == id) runOnUiThread(done) } })
        introTts.speak(message, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun launchPractice(name: String) {
        val i = Intent(this, PracticeService::class.java).apply { action = PracticeService.ACTION_START; putExtra("inhale", inhale); putExtra("inhaleHold", inhaleHold); putExtra("exhale", exhale); putExtra("exhaleHold", exhaleHold); putExtra("duration", duration); putExtra("technique", name); putExtra("sound", soundOn); putExtra("voice", selectedVoice) }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        showLive()
    }

    private fun showLive() {
        base("Stay with the rhythm.")
        val live = panel(); heading("Current phase", live)
        phaseText = text("Preparing", 15f, green, true).apply { gravity = Gravity.CENTER }
        countText = text("—", 54f, ink).apply { gravity = Gravity.CENTER }
        live.addView(phaseText); live.addView(countText); live.addView(text("seconds", 12f, muted).apply { gravity = Gravity.CENTER })
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        elapsedText = text("Elapsed 0:00", 13f); cyclesText = text("Cycles 0", 13f); remainingText = text("Remaining —", 13f)
        stats.addView(elapsedText, LinearLayout.LayoutParams(0, -2, 1f)); stats.addView(cyclesText, LinearLayout.LayoutParams(0, -2, 1f)); stats.addView(remainingText, LinearLayout.LayoutParams(0, -2, 1f)); live.addView(stats)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pauseButton = secondary("Ⅱ PAUSE") { sendService(if (paused) PracticeService.ACTION_RESUME else PracticeService.ACTION_PAUSE); paused = !paused; pauseButton.text = if (paused) "▶ RESUME" else "Ⅱ PAUSE" }
        actions.addView(pauseButton, LinearLayout.LayoutParams(0, -2, 1f)); actions.addView(secondary(if (soundOn) "🔔 SOUND" else "🔕 MUTED") { soundOn = !soundOn; startService(Intent(this, PracticeService::class.java).setAction(PracticeService.ACTION_SOUND).putExtra("sound", soundOn)) }, LinearLayout.LayoutParams(0, -2, 1f)); actions.addView(secondary("STOP") { sendService(PracticeService.ACTION_STOP); active = false; showSetup() }, LinearLayout.LayoutParams(0, -2, 1f)); live.addView(actions)
        addPanel(root, live)
        val details = panel(); heading("Session details", details); details.addView(text("Inhale $inhale sec  ·  Inhale hold $inhaleHold sec  ·  Exhale $exhale sec  ·  Exhale hold $exhaleHold sec", 14f)); details.addView(text("The app uses Android Text-to-Speech and a foreground audio service. You can lock the phone while the practice continues.", 13f, muted)); addPanel(root, details)
    }

    private fun renderLive(phase: String, count: Int, elapsed: Int, cycles: Int, target: Int, cycle: Int) {
        phaseText.text = phase.uppercase(Locale.getDefault()); countText.text = if (count > 0) count.toString() else "—"; elapsedText.text = "Elapsed ${clock(elapsed)}"; cyclesText.text = "Cycles $cycles/$target"; remainingText.text = "Remaining ${clock((target * cycle - elapsed).coerceAtLeast(0))}"
        if (phase == "Paused") { paused = true; pauseButton.text = "▶ RESUME" }
    }

    private fun sendService(action: String) { startService(Intent(this, PracticeService::class.java).setAction(action)) }
    private fun clock(seconds: Int) = String.format(Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60)

    private fun showCompletion(cycles: Int, elapsed: Int, cycle: Int) {
        base("Return to stillness.")
        val p = panel(); heading("Practice complete", p); p.addView(text("Your breathing practice is complete.", 17f)); p.addView(text("Total time ${clock(elapsed)}   ·   Cycles $cycles   ·   Cycle $cycle sec", 14f, green, true))
        p.addView(text("How did the breathing feel?", 14f)); val comfort = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Comfortable and steady", "A little challenging", "Uncomfortable — reduce intensity next time")) }; p.addView(comfort)
        p.addView(button("SAVE SESSION & DONE") { val choices = arrayOf("comfortable", "challenging", "uncomfortable"); val history = JSONArray(prefs.getString("history", "[]")); history.put(JSONObject().apply { put("date", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())); put("technique", PracticeData.techniques[selectedTechnique].name); put("inhale", inhale); put("inhaleHold", inhaleHold); put("exhale", exhale); put("exhaleHold", exhaleHold); put("duration", elapsed); put("cycles", cycles); put("comfort", choices[comfort.selectedItemPosition]) }); prefs.edit().putString("history", history.toString()).apply(); showSetup() })
        addPanel(root, p)
    }

    private fun saveCompletedSession(cycles: Int, elapsed: Int, cycle: Int) { /* Saved after the user selects comfort in the completion screen. */ }

    private fun populateProgress(p: LinearLayout) {
        val h = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val days = mutableSetOf<String>(); var streak = 0; var i = h.length() - 1
        while (i >= 0) { val item = h.optJSONObject(i) ?: break; days.add(item.optString("date")); if (item.optString("comfort") == "comfortable") streak++ else break; i-- }
        p.addView(text("Sessions saved: ${h.length()}     Practice days: ${h.toSetOfDates()}     Comfortable streak: $streak", 13f, green, true))
        p.addView(text("Current rhythm: In $inhale · Hold $inhaleHold · Out $exhale · Hold $exhaleHold", 13f))
        val last3 = (maxOf(0, h.length() - 3) until h.length()).map { h.optJSONObject(it)?.optString("comfort") }
        val ready = last3.size == 3 && last3.all { it == "comfortable" }
        p.addView(text(if (ready) "Your last 3 saved sessions were comfortable. Consider a one-second increase to exhale only if your teacher agrees and the current rhythm feels easy." else "Complete 3 comfortable sessions to review an optional next step. Breath holds will not be increased automatically.", 13f, muted))
        if (ready) p.addView(secondary("APPLY +1 SECOND TO EXHALE") { exhale = (exhale + 1).coerceAtMost(60); showSetup() })
        p.addView(secondary("RESET HISTORY") { AlertDialog.Builder(this).setMessage("Delete all saved practice history from this phone?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> prefs.edit().remove("history").apply(); showSetup() }.show() })
    }
    private fun JSONArray.toSetOfDates(): Int { val s = mutableSetOf<String>(); for (i in 0 until length()) s.add(optJSONObject(i)?.optString("date") ?: ""); return s.size }

    override fun onDestroy() { try { unregisterReceiver(receiver) } catch (_: Exception) {}; super.onDestroy() }
}
